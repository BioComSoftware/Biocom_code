##############################################################################
# Removal of the "__license__" line or content from  "__license__", or removal 
# of "__author__" in this or any constituent # component or file constitutes a 
# violation of the licensing and copyright agreement. 
__author__      = "Mike Rightmire"
__copyright__   = "BioCom Software"
__license__     = "Telemend"
__license_file__= "Clause1.PERPETUAL_AND_UNLIMITED_LICENSING_TO_THE_CLIENT.py"
__version__     = "0.9.0.0"
__maintainer__  = "Mike Rightmire"
__email__       = "Mike.Rightmire@BiocomSoftware.com"
__status__      = "Development"
##############################################################################
from qrnote.errorhandler   import handlertry
from qrnote.errorhandler   import raisetry

@handlertry("FATAL: rhandler._override_with_kw_vars")
def override_kw_vars(self, kwargs):
    for key in kwargs.keys():
        self.config.__dict__[key] =  kwargs[key]
    return True

def set_mandatory_defaults(self, _dict):
    """
    In the event the config file does not have the mandatory variables,
    and they are not passed in as __init__ variables, they can be set here.
    These defaults can be modified. The order of setting defaults should be:
    1. config file
    2. __init__ parameters
    3. Here (_set_mandatory_defaults)
    """
    for key in _dict.keys():
        if key not in self.config.__dict__.keys():
            self.config.__dict__[key] = _dict[key]
    return
