
from BiocomCommon.loghandler import log

import re
import subprocess

def RunSubprocess(command, verbose = True, output = "string"):
    """"""
    print "THIS IS THE RIGHT ONE!!!!!!!!!!" #333
    print 'output=', type(output), output #333
    # Check is an object passed. If so, use it
    result = False
    if isinstance(output, (str, list)):
        print 'it is a string or a list' 
        result = output
    else:
        if   re.search('st', str(output), re.ignorecase): result = str()
        elif re.search('(t)(e)?(xt)?', str(output), re.ignorecase): result = str()
        elif re.search('(l)(i)?(s)?(t)?', str(output), re.ignorecase): result = []

    print 'result = ', result #3333 
    if result is False: 
        err = ''.join(["BiocomCommon.RunSubprocess: ", "Unable to determine output type. ", "Parameter 'output' must be a Python object of 'str()' or 'list()' or the text 'string' or 'list'. "])
        raise ValueError(err)
        
    p = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    log.debug("RunSubprocess: " + str(command))

    while True:
        _stdout = p.stdout.readline()
        # If no _stdout, we're done...break out of the 'while True:' 
        if not _stdout: break
        # Store the output
        else:
            if   isinstance(result, str): result += _stdout
            elif isinstance(result, list): 
                _stdout = str(_stdout).rstrip('\r\n')
                result.append(_stdout)
            if verbose is True: log.debug("RunSubprocess:" + str(_stdout))

    return result
